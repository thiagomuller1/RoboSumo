#ifndef bridgeH_new
#define bridgeH_new

#include "Arduino.h"

class bridgeH_n{

  public:
  bridgeH_n(int pinA, int pinB, int pinEA, int speed); 
  bool statuspinA();                
  bool statuspinB();                
  bool statuspinEA();               
  int statusspeed();                


  private:
bool _pinA;
bool _pinB;
int _pinEA;

};




#endif