
#include "Arduino.h"
#include "sumo_new.h"

sumo_n::sumo_n(bool rWhite, bool lWhite, int dist, int distAttack, int tpRecover, int tpSearch)

{
_rWhite       = rWhite;
_lWhite       = lWhite;
_dist         = dist;
_distAttack   = distAttack;
_tpRecover    = tpRecover;
_tpSearch     = tpSearch;



if ((_dist<=_distAttack) &&  (!_rWhite) && (!_lWhite)  &&  (_index != 5) && (_index != 6) &&  (_index != 15)){
   _atTime = millis();     
  _index = 5;             
}


if ((_dist>_distAttack)  &&  (!_rWhite) && (!_lWhite)  &&  (_index != 10)  &&  (_index != 5)  &&  (_index != 6) && (_index != 15)){
  _atTime = millis();     
  _index = 10;             
}

if (((_rWhite) || (_lWhite)) &&  (_index != 15)) {
_atTime = millis();       
_index = 15;             
 };




//switchcase

switch (_index)

{
 
case 5:

if ((_dist<=_distAttack)  &&  (!_rWhite) && (!_lWhite)){
_RSpeed = 255; //255
_LSpeed = 255; // 255

}


if ((_dist>_distAttack)  &&  (!_rWhite) && (!_lWhite)){
  _index =6;
}

 break;

 case 6: 
_RSpeed = 100; 
_LSpeed = -100; 
if ((_dist<=_distAttack)  &&  (!_rWhite) && (!_lWhite)){
  _index =5;
}
 break;
 
  case 10: 
_RSpeed = -130;
_LSpeed = 130;

break;

 case 15: 
_RSpeed = -255;
_LSpeed = -255;
if ((millis()>=(_atTime+_tpSearch)) && (!_rWhite && (!_lWhite))){
   _atTime = millis();     
  _index =10;
}

 break;


  default:
_RSpeed = 0;
_LSpeed = 0;
 break;
}


};

int sumo_n::getRSpeed()              
{

return _RSpeed;

}
int sumo_n::getLSpeed()            
{
return _LSpeed;
}

int sumo_n::getIndex()
{
  return _index;
}

