
#ifndef sumo_new
#define sumo_new

#include "Arduino.h"

class sumo_n{

  public:
  sumo_n(bool rWhite, bool lWhite, int dist, int distAttack, int tpRecover, int tpSearch); 
  int getRSpeed();               
  int getLSpeed();               
  int getIndex();               

  private:
  bool  _rWhite;
  bool  _lWhite;
  int   _dist;
  int   _distAttack;
  int   _tpRecover;
  int   _tpSearch;
  int   _RSpeed;              
  int   _LSpeed;              
  int   _index;               
  unsigned long _atTime;     
};




#endif