
#include "Arduino.h"
#include "sharp_new.h"

sharp_n::sharp_n(const uint8_t sensPin)

{
_sensPin=(sensPin);
}
int sharp_n::getDistance()

{
int distance;

distance = (6762/(analogRead(_sensPin))-9)-4;


return distance;

};