
#ifndef sharp_new
#define sharp_new

#include "Arduino.h"

class sharp_n{

  public:
  sharp_n(const uint8_t sensPin);   
  int getDistance();              

  private:
  uint8_t _sensPin;
};




#endif