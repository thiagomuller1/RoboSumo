
#ifndef filtro_new
#define filtro_new

#include "Arduino.h"

class filtro_n{

  public:
 filtro_n(int analogValue, int numberSample, int timeSample );              
  float getanalogValueFilter();               
  
  float teste;

  private:
  int   _analogValue;         
  int   _numberSample;        
  int   _timeSample;          
  int   _vector[500];
  float   _analogValueFilter;   
  int   _indexVetor;          
  unsigned long _atTime;     
  float  _soma;        
};


#endif