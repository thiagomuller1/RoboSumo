
#include "Arduino.h"
#include "filtro_new.h"

filtro_n::filtro_n(int analogValue, int numberSample, int timeSample)

{
_analogValue      = analogValue;
_numberSample     = numberSample;
_timeSample       = timeSample;
teste ++;
}




float filtro_n::getanalogValueFilter()              
{


_indexVetor = _indexVetor+2.00 ;

 

if (millis()>=(_atTime+_timeSample)){
   _atTime = millis();     

   
}

return (teste);//_analogValueFilter;}
}